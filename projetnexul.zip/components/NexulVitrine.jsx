import React, { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import QRCode from "qrcode.react";
import { motion, useMotionValue, useTransform } from "framer-motion";
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from "recharts";
import i18n from "../lib/i18n";

export default function NexulVitrine() {
  const { t } = useTranslation();
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrollY, setScrollY] = useState(0);

  const changeLanguage = (lng) => i18n.changeLanguage(lng);
  const languages = ["fr","en"];

  // Tokenomics Data
  const tokenomicsData = [
    { name: t("services.reserve"), value: 51 },
    { name: t("services.publicSale"), value: 44 },
    { name: t("services.marketing"), value: 5 },
  ];
  const COLORS = ["#d4af37", "#ffcc00", "#ffaa00"];

  // Logo 3D
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const rotateY = useTransform(x, [-100, 100], [-15, 15]);
  const rotateX = useTransform(y, [-100, 100], [15, -15]);
  const handleMouseMove = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    x.set(e.clientX - rect.left - rect.width / 2);
    y.set(e.clientY - rect.top - rect.height / 2);
  };

  // Scroll parallax
  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);
  const bgOffset = scrollY * 0.15;
  const midOffset = scrollY * 0.4;
  const logoOffset = scrollY * 0.7;

  // Team & Partners
  const team = [
    { name: "S. Aissani", role: "Founder", image: "/team1.jpg", linkedin: "#" },
    { name: "J. Doe", role: "CTO", image: "/team2.jpg", linkedin: "#" },
  ];
  const partners = [
    { name: "Polygon", logo: "/polygon.png", url: "#" },
    { name: "Chainlink", logo: "/chainlink.png", url: "#" },
  ];

  // Roadmap milestones
  const roadmap = [
    { title: t("roadmap.m1.title"), desc: t("roadmap.m1.desc") },
    { title: t("roadmap.m2.title"), desc: t("roadmap.m2.desc") },
    { title: t("roadmap.m3.title"), desc: t("roadmap.m3.desc") },
  ];

  return (
    <div className="min-h-screen font-sans text-white bg-black">
      {/* Header */}
      <header className="fixed w-full z-50 bg-black/90 backdrop-blur-md shadow-md">
        <div className="max-w-6xl mx-auto flex items-center justify-between p-6">
          <div className="flex items-center gap-4">
            <img src="/symbole-nexul.jpg" alt="Logo Nexul" className="w-14 h-14 rounded"/>
            <div>
              <div className="text-xl font-bold">NEXUL</div>
              <div className="text-xs opacity-70">Ultimate Impact V3</div>
            </div>
          </div>

          <nav className="space-x-4 hidden md:flex">
            <a href="#home" className="hover:underline">{t("header.home")}</a>
            <a href="#about" className="hover:underline">{t("header.about")}</a>
            <a href="#services" className="hover:underline">{t("header.services")}</a>
            <a href="#whitepaper" className="bg-gold/80 text-black px-4 py-2 rounded font-semibold hover:scale-105 transition">{t("header.whitepaper")}</a>
          </nav>

          <div className="hidden md:flex gap-2">
            {languages.map(lng => (
              <button
                key={lng}
                onClick={() => changeLanguage(lng)}
                className={`text-sm px-2 py-1 border rounded hover:bg-gold hover:text-black transition ${i18n.language === lng ? 'bg-gold text-black' : ''}`}
              >
                {lng.toUpperCase()}
              </button>
            ))}
          </div>

          <button className="md:hidden text-2xl" onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? "✖" : "☰"}
          </button>
        </div>

        {menuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden bg-black/90 p-6 space-y-4 text-center"
          >
            <a href="#home" className="block">{t("header.home")}</a>
            <a href="#about" className="block">{t("header.about")}</a>
            <a href="#services" className="block">{t("header.services")}</a>
            <a href="#whitepaper" className="block bg-gold/80 text-black px-4 py-2 rounded font-semibold">{t("header.whitepaper")}</a>
            <div className="flex flex-wrap justify-center gap-2 mt-4">
              {languages.map(lng => (
                <button
                  key={lng}
                  onClick={() => changeLanguage(lng)}
                  className={`text-sm px-2 py-1 border rounded hover:bg-gold hover:text-black transition ${i18n.language === lng ? 'bg-gold text-black' : ''}`}
                >
                  {lng.toUpperCase()}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </header>

      {/* Hero */}
      <section
        id="home"
        className="relative min-h-screen flex items-center overflow-hidden bg-black"
        onMouseMove={handleMouseMove}
      >
        {/* Background */}
        <div className="absolute top-0 left-0 w-full h-full" style={{ transform: `translateY(${bgOffset}px)` }}>
          <div className="w-full h-full bg-gradient-to-b from-black via-gray-900 to-gray-800"></div>
        </div>

        {/* Particles glow */}
        <motion.div className="absolute w-full h-full pointer-events-none" style={{ transform: `translateY(${midOffset}px)` }}>
          {[...Array(20)].map((_, i) => (
            <div key={i} className="absolute w-2 h-2 bg-gold rounded-full opacity-60 blur-sm animate-bounce" style={{
              top: `${Math.random()*100}%`,
              left: `${Math.random()*100}%`,
              animationDelay: `${Math.random()*2}s`
            }} />
          ))}
        </motion.div>

        <div className="max-w-6xl mx-auto px-6 py-24 flex flex-col md:flex-row items-center gap-12 relative z-10">
          {/* Hero Text */}
          <motion.div className="md:w-1/2" initial={{ x: -50, opacity: 0 }} whileInView={{ x:0, opacity:1 }} viewport={{ once:true }} transition={{ duration:1 }}>
            <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight text-gold">{t("hero.title")}</h1>
            <p className="mt-6 text-lg opacity-80">{t("hero.subtitle")}</p>
            <div className="mt-8 flex gap-4 flex-wrap">
              <motion.a whileHover={{ scale: 1.05 }} href="#about" className="px-6 py-3 rounded border border-gold text-gold font-semibold transition">{t("hero.discover")}</motion.a>
              <motion.a whileHover={{ scale: 1.05 }} href="#services" className="px-6 py-3 rounded bg-gold text-black font-semibold transition">{t("hero.tokenomics")}</motion.a>
            </div>
            <div className="mt-8">
              <div className="text-sm opacity-70 mb-4">By S. Aissani — Contract vérifié sur Polygon</div>
              <div className="flex gap-4 items-center flex-wrap">
                <QRCode value="https://buy-nexul.com" size={100} aria-label="Scanner pour acheter le token Nexul"/>
                <motion.a whileHover={{ scale: 1.05 }} href="https://buy-nexul.com" target="_blank" rel="noopener noreferrer" className="px-4 py-2 rounded bg-gold text-black font-semibold transition">{t("buy.button")}</motion.a>
              </div>
              <p className="text-sm opacity-70 mt-2">{t("buy.desc")}</p>
            </div>
          </motion.div>

          {/* Logo 3D */}
          <motion.div className="md:w-1/2 flex justify-center" style={{ perspective: 800, transform: `translateY(${logoOffset}px)` }}>
            <motion.div
              style={{ rotateX, rotateY }}
              className="w-80 h-80 rounded-xl flex items-center justify-center bg-gradient-radial from-gold/10 via-transparent to-black/30 hover:scale-105 transition-transform shadow-lg"
            >
              <img src="/symbole-nexul.jpg" alt="Nexul" className="w-56 h-56 object-contain"/>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-gradient-to-b from-green-50 to-green-100 text-gray-900">
        <div className="max-w-6xl mx-auto px-6">
          <motion.h2 className="text-3xl font-bold" initial={{ opacity:0, y:50 }} whileInView={{opacity:1, y:0}} viewport={{once:true}}>{t("about.title")}</motion.h2>
          <motion.p className="mt-4 max-w-3xl" initial={{ opacity:0, y:20 }} whileInView={{opacity:1, y:0}} viewport={{once:true}}>{t("about.mission")}</motion.p>
          <motion.p className="mt-2 max-w-3xl" initial={{ opacity:0, y:20 }} whileInView={{opacity:1, y:0}} viewport={{once:true}}>{t("about.vision")}</motion.p>
          <div className="mt-8 grid md:grid-cols-3 gap-6">
            <div className="p-6 rounded-xl bg-white shadow">
              <h3 className="font-semibold">{t("about.impact")}</h3>
              <p className="mt-2 text-sm opacity-80">{t("about.impactDesc")}</p>
            </div>
            <div className="p-6 rounded-xl bg-white shadow">
              <h3 className="font-semibold">{t("about.access")}</h3>
              <p className="mt-2 text-sm opacity-80">{t("about.accessDesc")}</p>
            </div>
            <div className="p-6 rounded-xl bg-white shadow">
              <h3 className="font-semibold">{t("about.transparency")}</h3>
              <p className="mt-2 text-sm opacity-80">{t("about.transparencyDesc")}</p>
            </div>
          </div>
        </div>
      </section>

      {/* Tokenomics Section */}
      <section id="services" className="py-20 bg-gradient-to-b from-gray-900 to-black text-white">
        <div className="max-w-6xl mx-auto px-6">
          <motion.h2 className="text-3xl font-bold text-gold" initial={{opacity:0, y:50}} whileInView={{opacity:1, y:0}} viewport={{once:true}}>{t("services.title")}</motion.h2>
          <div className="mt-8 flex flex-col md:flex-row gap-6 items-center">
            <div className="md:w-1/2 p-6 rounded-xl bg-slate-900">
              <p className="opacity-80">{t("services.desc")}</p>
              <div className="mt-4">
                <ul className="text-sm opacity-80 space-y-2">
                  <li>• {t("services.reserve")}: 51%</li>
                  <li>• {t("services.publicSale")}: 44%</li>
                  <li>• {t("services.marketing")}: 5%</li>
                </ul>
              </div>
            </div>
            <div className="md:w-1/2 h-64 p-4 bg-slate-900 rounded-xl">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={tokenomicsData} dataKey="value" nameKey="name" outerRadius={80}>
                    {tokenomicsData.map((entry, index) => <Cell key={index} fill={COLORS[index % COLORS.length]} />)}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </section>

      {/* Team & Partners */}
      <section id="team" className="py-16 bg-black text-white">
        <div className="max-w-6xl mx-auto px-6">
          <h3 className="text-2xl font-bold">{t("team.title")}</h3>
          <div className="mt-6 grid md:grid-cols-4 gap-6">
            {team.map((m, i) => (
              <div key={i} className="p-4 bg-slate-900 rounded text-center">
                <img src={m.image} alt={m.name} className="mx-auto w-24 h-24 rounded-full object-cover"/>
                <div className="mt-2 font-semibold">{m.name}</div>
                <div className="text-sm opacity-70">{m.role}</div>
              </div>
            ))}
          </div>

          <div className="mt-8">
            <h4 className="font-semibold">{t("partners.title")}</h4>
            <div className="mt-4 flex gap-6 items-center">
              {partners.map((p, i) => (
                <a key={i} href={p.url} className="inline-block">
                  <img src={p.logo} alt={p.name} className="w-32 h-auto object-contain"/>
                </a>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Roadmap */}
      <section id="roadmap" className="py-16 bg-gray-100 text-gray-900">
        <div className="max-w-6xl mx-auto px-6">
          <h3 className="text-2xl font-bold">{t("roadmap.title")}</h3>
          <div className="mt-6 space-y-4">
            {roadmap.map((r, i) => (
              <div key={i} className="p-4 bg-white rounded shadow">
                <div className="font-semibold">{r.title}</div>
                <div className="text-sm opacity-80 mt-1">{r.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 bg-black text-white">
        <div className="max-w-6xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center">
          <div>
            <div className="font-bold">NEXUL</div>
            <div className="text-sm opacity-70">© {new Date().getFullYear()} Nexul. All rights reserved.</div>
          </div>
          <div className="mt-4 md:mt-0">
            <a href="/dashboard" className="px-4 py-2 rounded bg-gold text-black font-semibold">Dashboard</a>
          </div>
        </div>
      </footer>
    </div>
  );
}

import NexulVitrine from '../components/NexulVitrine'

export default function Home() {
  return <NexulVitrine />
}
